package com.example.eva_1_4_frag_parametros;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void crearFragment(View v){
        //TRANSACCION
        FragmentTransaction ft= getSupportFragmentManager().beginTransaction();
        //CREAR EL FRAGMENTO
        ParamFragment paramFragment= ParamFragment.newInstance("HOLA MUNDO!!","VALORES ASIGNADOS AL FRAGMENTO");
        //REMPLAZAR NUESTRO LAYOUT CON EL FRAGMENTO
        ft.replace(R.id.framLyt,paramFragment);
        //COMMIT
        ft.commit();
    }
}
